
import React, {  } from 'react'
import {  Form } from 'semantic-ui-react'

function SentenceTask() {
 return (

 <Form>
<Form.TextArea label='Answer'   placeholder='Provide your answers'   />
   
 </Form>     
    )
  }
export default SentenceTask